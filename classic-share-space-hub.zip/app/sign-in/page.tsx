import Link from 'next/link'
import { redirect } from 'next/navigation'
import { headers } from 'next/headers'
import { auth } from '@/lib/auth'
import { AuthForm } from '@/components/auth-form'

export default async function SignInPage() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (session?.user) redirect('/')
  return <main className="flex min-h-screen items-center justify-center bg-[#f6f8fa] px-5 py-10"><section className="w-full max-w-md rounded-[24px] border border-[#dbe4ea] bg-white p-7 shadow-[0_12px_40px_rgba(21,45,64,0.08)] sm:p-9"><div className="mb-8 flex items-center gap-3"><div className="flex size-10 items-center justify-center rounded-xl bg-[#27b4a5] font-bold text-white">S</div><div><p className="font-bold text-[#10283f]">ShareSpace</p><p className="text-[10px] uppercase tracking-[0.18em] text-[#8096a4]">Campus commons</p></div></div><h1 className="text-2xl font-bold tracking-tight text-[#102e3d]">Welcome back</h1><p className="mt-2 mb-7 text-sm text-[#78909c]">Sign in to manage your shared resources and bookings.</p><AuthForm mode="sign-in" /><p className="mt-6 text-center text-sm text-[#78909c]">New to ShareSpace? <Link className="font-semibold text-[#159a91] hover:underline" href="/sign-up">Create an account</Link></p></section></main>
}
