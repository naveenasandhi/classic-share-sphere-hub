'use client'

import { FormEvent, useState } from 'react'
import { useRouter } from 'next/navigation'
import { ArrowRight, Loader2 } from 'lucide-react'
import { authClient } from '@/lib/auth-client'

export function AuthForm({ mode }: { mode: 'sign-in' | 'sign-up' }) {
  const router = useRouter()
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [pending, setPending] = useState(false)
  const isSignUp = mode === 'sign-up'

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setError('')
    setPending(true)
    const result = isSignUp
      ? await authClient.signUp.email({ name, email, password })
      : await authClient.signIn.email({ email, password })
    setPending(false)
    if (result.error) {
      setError('We could not complete that request. Check your details and try again.')
      return
    }
    router.push('/')
    router.refresh()
  }

  return <form onSubmit={handleSubmit} className="flex flex-col gap-4">
    {isSignUp && <label className="flex flex-col gap-2 text-sm font-semibold">Full name<input required value={name} onChange={(event) => setName(event.target.value)} className="rounded-xl border border-[#dbe4ea] bg-white px-4 py-3 font-normal outline-none ring-[#27b4a5] focus:ring-2" placeholder="Aarav Rao" /></label>}
    <label className="flex flex-col gap-2 text-sm font-semibold">Email<input required type="email" value={email} onChange={(event) => setEmail(event.target.value)} className="rounded-xl border border-[#dbe4ea] bg-white px-4 py-3 font-normal outline-none ring-[#27b4a5] focus:ring-2" placeholder="you@campus.edu" /></label>
    <label className="flex flex-col gap-2 text-sm font-semibold">Password<input required minLength={8} type="password" value={password} onChange={(event) => setPassword(event.target.value)} className="rounded-xl border border-[#dbe4ea] bg-white px-4 py-3 font-normal outline-none ring-[#27b4a5] focus:ring-2" placeholder="At least 8 characters" /></label>
    {error && <p role="alert" className="rounded-xl bg-[#fff1ee] px-3 py-2 text-sm text-[#b14d42]">{error}</p>}
    <button disabled={pending} className="mt-2 flex items-center justify-center gap-2 rounded-xl bg-[#102e3d] px-5 py-3.5 text-sm font-semibold text-white transition hover:bg-[#17465a] disabled:opacity-60">{pending ? <Loader2 className="size-4 animate-spin" /> : <>{isSignUp ? 'Create account' : 'Sign in'}<ArrowRight className="size-4" /></>}</button>
  </form>
}
