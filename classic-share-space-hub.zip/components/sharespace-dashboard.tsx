'use client'

import { memo, useMemo, useState } from 'react'
import {
  AlertTriangle,
  ArrowRight,
  Bell,
  CalendarDays,
  CheckCircle2,
  ChevronDown,
  Clock3,
  Filter,
  Grid2X2,
  LayoutDashboard,
  ListFilter,
  MapPin,
  Menu,
  PackageOpen,
  Plus,
  Search,
  Settings2,
  ShieldCheck,
  Sparkles,
  Users,
  X,
} from 'lucide-react'

const resources = [
  { name: 'Prusa MK4 3D Printer', category: 'Fabrication', location: 'Innovation Lab · Block C', status: 'Available', color: 'teal', icon: '3D', bookings: 18, next: 'Available today', owner: 'Makerspace Team', image: '/images/resource-3d-printer.png' },
  { name: 'Sony Alpha A7 IV Kit', category: 'Media & Design', location: 'Media Studio · Block A', status: 'Available', color: 'blue', icon: 'CAM', bookings: 12, next: 'Available tomorrow', owner: 'Visual Arts Dept.', image: '/images/resource-camera.png' },
  { name: 'Keysight Oscilloscope', category: 'Electronics', location: 'ECE Lab · Block B', status: 'In use', color: 'amber', icon: 'OSC', bookings: 26, next: 'Free Friday, 2:00 PM', owner: 'Electronics Lab', image: '/images/resource-oscilloscope.png' },
  { name: 'Portable Projector', category: 'Events & Rooms', location: 'Central Store · Admin', status: 'Available', color: 'violet', icon: 'PRO', bookings: 9, next: 'Available today', owner: 'Campus Operations', image: '/images/resource-projector.png' },

]

const navItems = [
  { label: 'Overview', icon: LayoutDashboard },
  { label: 'Discover resources', icon: Search },
  { label: 'My bookings', icon: CalendarDays },
  { label: 'Activity history', icon: Clock3 },
]

export function ShareSpaceDashboard() {
  const [activeNav, setActiveNav] = useState('Overview')
  const [query, setQuery] = useState('')
  const [category, setCategory] = useState('All categories')
  const [mobileNav, setMobileNav] = useState(false)
  const [showFilters, setShowFilters] = useState(false)
  const [role, setRole] = useState<'user' | 'admin'>('user')
  const [notice, setNotice] = useState('')
  const [savedResources, setSavedResources] = useState<string[]>([])

  const notify = (message: string) => {
    setNotice(message)
    window.setTimeout(() => setNotice(''), 2400)
  }

  const toggleSaved = (name: string) => {
    setSavedResources((current) => current.includes(name) ? current.filter((item) => item !== name) : [...current, name])
    notify(savedResources.includes(name) ? `${name} removed from saved resources` : `${name} saved to your resources`)
  }

  const filteredResources = useMemo(() => resources.filter((resource) => {
    const matchesQuery = `${resource.name} ${resource.category} ${resource.location}`.toLowerCase().includes(query.toLowerCase())
    const matchesCategory = category === 'All categories' || resource.category === category
    return matchesQuery && matchesCategory
  }), [query, category])

  return (
    <div className="min-h-screen bg-[#f6f8fa] text-[#11263d]">
      {notice && <div role="status" className="fixed bottom-5 right-5 z-50 rounded-xl bg-[#10283f] px-4 py-3 text-xs font-semibold text-white shadow-xl">{notice}</div>}
      <aside className={`${mobileNav ? 'translate-x-0' : '-translate-x-full'} fixed inset-y-0 left-0 z-30 flex w-[272px] flex-col border-r border-[#dbe4ea] bg-[#10283f] text-white transition-transform md:translate-x-0`}>
        <div className="flex h-[82px] items-center justify-between border-b border-white/10 px-7">
          <div className="flex items-center gap-3">
            <div className="flex size-9 items-center justify-center rounded-xl bg-[#27b4a5] font-bold tracking-tight text-white">S</div>
            <div><div className="text-[17px] font-bold tracking-tight">ShareSpace</div><div className="text-[10px] uppercase tracking-[0.2em] text-[#9fb3c2]">Campus commons</div></div>
          </div>
          <button className="md:hidden" onClick={() => setMobileNav(false)} aria-label="Close navigation"><X /></button>
        </div>
        <div className="flex flex-1 flex-col px-4 py-7">
          <div className="mb-3 px-3 text-[10px] font-semibold uppercase tracking-[0.18em] text-[#7e98aa]">Workspace</div>
          <nav className="flex flex-col gap-1">
            {navItems.map(({ label, icon: Icon }) => <button key={label} onClick={() => { setActiveNav(label); setMobileNav(false) }} className={`flex items-center gap-3 rounded-xl px-3 py-3 text-left text-[13px] font-medium transition ${activeNav === label ? 'bg-white/12 text-white shadow-sm' : 'text-[#a9bbc7] hover:bg-white/7 hover:text-white'}`}><Icon className="size-[17px]" />{label}{label === 'My bookings' && <span className="ml-auto rounded-md bg-[#f5b544] px-1.5 py-0.5 text-[10px] font-bold text-[#4b3610]">2</span>}</button>)}
          </nav>
          <div className="mb-3 mt-10 px-3 text-[10px] font-semibold uppercase tracking-[0.18em] text-[#7e98aa]">Manage</div>
          <nav className="flex flex-col gap-1">
            <button onClick={() => notify('My resources is ready to manage')} className="flex items-center gap-3 rounded-xl px-3 py-3 text-left text-[13px] font-medium text-[#a9bbc7] hover:bg-white/7 hover:text-white"><PackageOpen className="size-[17px]" />My resources</button>
            <button onClick={() => notify('Community directory opened')} className="flex items-center gap-3 rounded-xl px-3 py-3 text-left text-[13px] font-medium text-[#a9bbc7] hover:bg-white/7 hover:text-white"><Users className="size-[17px]" />Community</button>
            <button onClick={() => setRole('admin')} className={`flex items-center gap-3 rounded-xl px-3 py-3 text-left text-[13px] font-medium ${role === 'admin' ? 'bg-[#27b4a5]/20 text-white' : 'text-[#a9bbc7] hover:bg-white/7 hover:text-white'}`}><ShieldCheck className="size-[17px]" />Admin console</button>
            <button className="flex items-center gap-3 rounded-xl px-3 py-3 text-left text-[13px] font-medium text-[#a9bbc7] hover:bg-white/7 hover:text-white"><ShieldCheck className="size-[17px]" />Safety & policies</button>
          </nav>
          <div className="mt-auto rounded-2xl border border-white/10 bg-white/5 p-4"><div className="mb-2 flex items-center gap-2 text-[#71dfd2]"><Sparkles className="size-4" /><span className="text-xs font-semibold">Share responsibly</span></div><p className="text-[11px] leading-5 text-[#a9bbc7]">Every shared resource helps our community do more with less.</p><button className="mt-3 text-[11px] font-semibold text-white underline decoration-[#27b4a5] underline-offset-4">View community guidelines</button></div>
        </div>
        <div className="border-t border-white/10 p-4"><div className="mb-2 grid grid-cols-2 gap-1 rounded-lg bg-white/5 p-1"><button onClick={() => setRole('user')} className={`rounded-md px-2 py-1.5 text-[10px] font-semibold ${role === 'user' ? 'bg-white text-[#10283f]' : 'text-[#a9bbc7]'}`}>User view</button><button onClick={() => setRole('admin')} className={`rounded-md px-2 py-1.5 text-[10px] font-semibold ${role === 'admin' ? 'bg-[#27b4a5] text-white' : 'text-[#a9bbc7]'}`}>Admin view</button></div><button className="flex w-full items-center gap-3 rounded-xl p-2 text-left hover:bg-white/7"><div className="flex size-9 items-center justify-center rounded-full bg-[#d6eceb] text-xs font-bold text-[#0e6664]">N</div><div className="min-w-0 flex-1"><div className="truncate text-xs font-semibold">Naveena</div><div className="truncate text-[10px] text-[#91a8b7]">{role === 'admin' ? 'Administrator · Verified' : 'Member · Verified'}</div></div><ChevronDown className="size-4 text-[#91a8b7]" /></button></div>
      </aside>

      <div className="md:pl-[272px]">
        <header className="sticky top-0 z-20 flex h-[82px] items-center justify-between border-b border-[#dbe4ea] bg-[#f6f8fa]/95 px-5 backdrop-blur-md sm:px-8 lg:px-10">
          <div className="flex items-center gap-3"><button className="md:hidden" onClick={() => setMobileNav(true)} aria-label="Open navigation"><Menu className="size-5" /></button><div><p className="text-xs font-medium text-[#7690a1]">Tuesday, 28 October 2026 · {role === 'admin' ? 'Admin console' : 'Member workspace'}</p><h1 className="text-xl font-bold tracking-[-0.02em] sm:text-2xl">Good morning, Naveena</h1></div></div>
          <div className="flex items-center gap-2 sm:gap-4"><button className="relative rounded-xl p-2.5 text-[#5d7485] hover:bg-white" aria-label="Notifications"><Bell className="size-[19px]" /><span className="absolute right-2 top-2 size-1.5 rounded-full bg-[#ee6c5d]" /></button><div className="hidden h-7 w-px bg-[#dbe4ea] sm:block" /><button className="flex items-center gap-2 rounded-xl border border-[#dbe4ea] bg-white px-3 py-2 text-xs font-semibold shadow-sm"><span className="flex size-6 items-center justify-center rounded-full bg-[#d6eceb] text-[9px] text-[#0e6664]">AR</span><span className="hidden sm:inline">My profile</span><ChevronDown className="size-3.5 text-[#8093a0]" /></button></div>
        </header>

        <main className="mx-auto max-w-[1440px] px-5 py-7 sm:px-8 lg:px-10 lg:py-10">
          <section className="mb-8 grid gap-6 xl:grid-cols-[1fr_310px]">
            <div className="rounded-[22px] bg-[#dff3f0] p-6 sm:p-8"><div className="max-w-2xl"><div className="mb-3 inline-flex items-center gap-2 rounded-full border border-[#9ed9d2] bg-white/55 px-3 py-1.5 text-[10px] font-bold uppercase tracking-[0.14em] text-[#147d77]"><Sparkles className="size-3.5" />Discover shared resources</div><h2 className="max-w-xl text-3xl font-bold leading-[1.1] tracking-[-0.04em] text-[#102e3d] sm:text-[39px]">Access more.<br /><span className="text-[#159a91]">Waste less.</span></h2><p className="mt-4 max-w-lg text-sm leading-6 text-[#52716f]">Find the equipment, spaces, and expertise your next project needs — shared by your campus community.</p><div className="mt-6 flex flex-col gap-2 sm:flex-row"><div className="flex flex-1 items-center gap-3 rounded-xl border border-white bg-white px-4 py-3 shadow-sm"><Search className="size-[18px] text-[#70918e]" /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search equipment, rooms, tools..." className="min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-[#91aaa8]" /></div><button onClick={() => setActiveNav('Discover resources')} className="rounded-xl bg-[#102e3d] px-5 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-[#17465a]">Explore resources <ArrowRight className="ml-2 inline size-4" /></button></div></div></div>
            <div className="rounded-[22px] border border-[#dbe4ea] bg-white p-6 shadow-[0_4px_18px_rgba(21,45,64,0.03)]"><div className="mb-5 flex items-center justify-between"><div><p className="text-xs font-semibold uppercase tracking-[0.14em] text-[#8096a4]">Your impact</p><h3 className="mt-1 text-lg font-bold">Community contribution</h3></div><div className="flex size-9 items-center justify-center rounded-xl bg-[#edf8f6] text-[#159a91]"><Users className="size-[18px]" /></div></div><div className="flex items-end gap-2"><span className="text-4xl font-bold tracking-[-0.05em]">14.6</span><span className="mb-1 text-xs text-[#78909c]">hours shared</span></div><div className="mt-4 h-2 overflow-hidden rounded-full bg-[#e9eff2]"><div className="h-full w-[68%] rounded-full bg-[#27b4a5]" /></div><div className="mt-2 flex justify-between text-[11px] text-[#8096a4]"><span>68% of monthly goal</span><span className="font-semibold text-[#159a91]">+2.4 hrs</span></div><div className="mt-5 border-t border-[#edf1f3] pt-4 text-xs text-[#597180]">You helped avoid <span className="font-bold text-[#102e3d]">3.2 kg</span> of duplicate purchases this month.</div></div>
          </section>

          <section className="mb-9 grid grid-cols-2 gap-3 sm:grid-cols-4 sm:gap-4"><Stat label="Active bookings" value="2" note="1 due this week" icon={CalendarDays} tone="teal" /><Stat label="Pending requests" value="3" note="Awaiting review" icon={Clock3} tone="amber" /><Stat label="Saved resources" value="8" note="Across 4 categories" icon={PackageOpen} tone="blue" /><Stat label="Trust score" value="98%" note="Excellent standing" icon={ShieldCheck} tone="green" /></section>

          <section><div className="mb-4 flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><div><div className="flex items-center gap-2"><h2 className="text-xl font-bold tracking-[-0.02em]">Recommended for you</h2><span className="rounded-full bg-[#e8f6f4] px-2 py-1 text-[10px] font-bold text-[#168e86]">MATCHED</span></div><p className="mt-1 text-xs text-[#78909c]">Based on your interests, training, and availability</p></div><button className="flex items-center gap-2 self-start rounded-lg text-xs font-semibold text-[#587283] hover:text-[#159a91]" onClick={() => setShowFilters(!showFilters)}><Filter className="size-4" />Filters <span className="rounded-full bg-[#e9eff2] px-1.5 text-[10px]">3</span></button></div>
            {showFilters && <div className="mb-4 flex flex-wrap items-center gap-2 rounded-xl border border-[#dbe4ea] bg-white p-3"><select value={category} onChange={(event) => setCategory(event.target.value)} className="rounded-lg border border-[#dbe4ea] bg-white px-3 py-2 text-xs font-medium outline-none"><option>All categories</option><option>Fabrication</option><option>Media & Design</option><option>Electronics</option><option>Events & Rooms</option></select><button onClick={() => { setCategory('All categories'); setQuery('') }} className="text-xs font-semibold text-[#159a91]">Clear filters</button></div>}
            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">{filteredResources.map((resource) => <ResourceCard key={resource.name} resource={resource} saved={savedResources.includes(resource.name)} onSave={() => toggleSaved(resource.name)} onBook={() => notify(`Booking request started for ${resource.name}`)} />)}</div>
            {filteredResources.length === 0 && <div className="rounded-2xl border border-dashed border-[#cddae1] bg-white py-12 text-center"><Search className="mx-auto size-8 text-[#9db0bb]" /><p className="mt-3 font-semibold">No resources found</p><p className="mt-1 text-xs text-[#78909c]">Try a different search or clear your filters.</p></div>}
            <button onClick={() => setActiveNav('Discover resources')} className="mx-auto mt-6 flex items-center gap-2 text-xs font-bold text-[#159a91]">View all resources <ArrowRight className="size-4" /></button></section>

          <section className="mt-12 grid gap-6 xl:grid-cols-[1.2fr_0.8fr]"><div className="rounded-2xl border border-[#dbe4ea] bg-white p-6"><div className="mb-5 flex items-center justify-between"><div><h2 className="text-lg font-bold">Upcoming activity</h2><p className="mt-1 text-xs text-[#78909c]">Your next steps at a glance</p></div><button className="text-xs font-semibold text-[#159a91]">View calendar</button></div><div className="flex items-center gap-4 rounded-xl bg-[#f6f8fa] p-4"><div className="flex size-12 flex-col items-center justify-center rounded-xl bg-white text-[#159a91] shadow-sm"><span className="text-[10px] font-bold uppercase">Nov</span><span className="text-lg font-bold leading-4">02</span></div><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><p className="truncate text-sm font-bold">Prusa MK4 3D Printer</p><span className="rounded-full bg-[#e8f6f4] px-2 py-1 text-[9px] font-bold text-[#168e86]">APPROVED</span></div><p className="mt-1 text-xs text-[#78909c]">10:00 AM – 12:00 PM · Innovation Lab</p></div><button className="hidden rounded-lg border border-[#dbe4ea] bg-white px-3 py-2 text-xs font-semibold sm:block">Details</button></div><div className="mt-3 flex items-center gap-4 rounded-xl border border-[#edf1f3] p-4"><div className="flex size-12 flex-col items-center justify-center rounded-xl bg-[#fff7e7] text-[#b77b13]"><span className="text-[10px] font-bold uppercase">Nov</span><span className="text-lg font-bold leading-4">08</span></div><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><p className="truncate text-sm font-bold">Sony Alpha A7 IV Kit</p><span className="rounded-full bg-[#fff3d8] px-2 py-1 text-[9px] font-bold text-[#ac7410]">PENDING</span></div><p className="mt-1 text-xs text-[#78909c]">All day · Media Studio</p></div><button className="hidden rounded-lg border border-[#dbe4ea] bg-white px-3 py-2 text-xs font-semibold sm:block">Details</button></div></div><div className="rounded-2xl bg-[#102e3d] p-6 text-white"><div className="flex items-center justify-between"><div><h2 className="text-lg font-bold">Need a hand?</h2><p className="mt-1 text-xs leading-5 text-[#a8c0ca]">Learn how to borrow safely and make the most of shared resources.</p></div><div className="flex size-10 items-center justify-center rounded-xl bg-white/10 text-[#72ded3]"><ShieldCheck className="size-5" /></div></div><div className="mt-6 flex flex-col gap-2"><button className="flex items-center justify-between rounded-xl bg-white/10 px-4 py-3 text-left text-xs font-semibold hover:bg-white/15"><span>How borrowing works</span><ArrowRight className="size-4 text-[#72ded3]" /></button><button className="flex items-center justify-between rounded-xl bg-white/10 px-4 py-3 text-left text-xs font-semibold hover:bg-white/15"><span>Complete your safety profile</span><ArrowRight className="size-4 text-[#72ded3]" /></button></div></div></section>
        </main>
      </div>
    </div>
  )
}

const Stat = memo(function Stat({ label, value, note, icon: Icon, tone }: { label: string; value: string; note: string; icon: typeof CalendarDays; tone: string }) { return <div className="rounded-2xl border border-[#dbe4ea] bg-white p-4 shadow-[0_4px_18px_rgba(21,45,64,0.02)] sm:p-5"><div className={`mb-4 flex size-9 items-center justify-center rounded-xl ${tone === 'amber' ? 'bg-[#fff5df] text-[#b57a13]' : tone === 'blue' ? 'bg-[#eaf2fb] text-[#3975ad]' : tone === 'green' ? 'bg-[#edf8f1] text-[#3a9361]' : 'bg-[#e8f6f4] text-[#159a91]'}`}><Icon className="size-[17px]" /></div><div className="text-2xl font-bold tracking-[-0.04em] sm:text-3xl">{value}</div><div className="mt-1 text-xs font-semibold text-[#526c7d]">{label}</div><div className="mt-1 text-[10px] text-[#8ca0ab]">{note}</div></div> })

const ResourceCard = memo(function ResourceCard({ resource, saved, onSave, onBook }: { resource: typeof resources[number]; saved: boolean; onSave: () => void; onBook: () => void }) { const colors = { teal: 'from-[#cceeea] to-[#eaf8f6] text-[#167b75]', blue: 'from-[#d8e8f6] to-[#eef5fb] text-[#3975ad]', amber: 'from-[#fae8bd] to-[#fff6e5] text-[#a7751a]', violet: 'from-[#e5def6] to-[#f5f1fb] text-[#7054a7]' }; return <article className="group overflow-hidden rounded-2xl border border-[#dbe4ea] bg-white transition hover:-translate-y-0.5 hover:shadow-[0_8px_25px_rgba(21,45,64,0.08)]"><div className={`relative flex h-32 items-center justify-center overflow-hidden bg-gradient-to-br ${colors[resource.color as keyof typeof colors]}`}><img src={resource.image} alt={`${resource.name} in use`} className="size-full object-cover mix-blend-multiply opacity-90" /><div className="absolute inset-0 bg-gradient-to-t from-[#10283f]/35 to-transparent" /><div className="absolute bottom-3 left-3 rounded-lg border border-white/40 bg-white/70 px-2 py-1 text-[10px] font-black tracking-tight text-[#163248]">{resource.icon}</div><span className={`absolute right-3 top-3 rounded-full px-2 py-1 text-[9px] font-bold ${resource.status === 'Available' ? 'bg-white/85 text-[#187f77]' : 'bg-[#fff5dc] text-[#a57418]'}`}>{resource.status}</span></div><div className="p-4"><div className="mb-2 flex items-center justify-between"><span className="text-[10px] font-bold uppercase tracking-[0.12em] text-[#8197a4]">{resource.category}</span><button onClick={onSave} className={`${saved ? 'text-[#159a91]' : 'text-[#9cafb8]'} hover:text-[#159a91]`} aria-label={`${saved ? 'Remove' : 'Save'} ${resource.name}`}><Plus className="size-4" /></button></div><h3 className="text-sm font-bold leading-5 text-[#163248]">{resource.name}</h3><div className="mt-3 flex items-center gap-1.5 text-[10px] text-[#78909c]"><MapPin className="size-3.5" />{resource.location}</div><div className="mt-3 flex items-center justify-between border-t border-[#edf1f3] pt-3"><span className="text-[10px] text-[#78909c]">{resource.next}</span><span className="text-[10px] font-bold text-[#159a91]">{resource.bookings} bookings</span></div></div></article> })
